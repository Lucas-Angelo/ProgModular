    // Fun��o ser privada pelo Fator de Integridade
    // Nome da funcao alterada para Fator de Legibilidade
    private static String verificarAprovacao() {

        // Zerar vari�vel para garantir que n�o exista lixo da mem�ria e adequar ao Fato de Corre��o
        // Somat�rio da notaFinal ser double para o Fator de Robustez caso a nota n�o seja exata
        double notaFinal=0;

        // Com finalidade de aumentar a Legibilidade, retornar o que ocorreu diretamente com o aluno
        // Talvez isso impactaria minimamente no fator de Efici�ncia, pois uma String gasta mais que int
        String status = new String();

        // Somar dinamicamente para garantir o Fator de Reusabilidade dessa fun��o caso aja necessidade
        for(int i=0; i<nota.length; i++)
            notaFinal+=nota[i];

        /* Com objetivo de diminuir a quantiade de comparac�es, utilizei o frequ�ncia como condi��o principal,
        j� que se a frequ�ncia for menor que 0.75 n�o precisa fazer mais compara��es, est� reprovado. */
        // Mudan�a feito para agregar um m�nimo Fator de Efici�ncia
        if(frequencia<0.75)
            status="Reprovado";
        else
            if(notaFinal>=60)
                status="Aprovado";
            else
                status="Reavali��o";

        return status;
    }
