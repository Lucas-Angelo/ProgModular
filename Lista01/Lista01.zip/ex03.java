    // Função privada por fator de Integridade
    // Função recebe por parâmetro os dados que podem ser enviados de forma modularizada
    // Função retornando a média em double, com isso aumentando a Modularidade podendo tratar o retorno
    private static double calcularMedia(){
        double mediaTurma;
        // Para tratar a exessão de divisão por 0, aumentando Fator de Robustez
        if(notas.length!=0) {
            // Por Fator de Robustez, notas e somas são em double para caso exista uma nota não exata
            double somatorio = 0;
            // Apenas um for pois agora é Modularizado
            for (int i = 0; i < notas.length; i++) {
                somatorio += notas[i];
            }
            // Casting double para aumentar o Fator de Robustez
            mediaTurma = somatorio / ((double) notas.length);
        } else {
            mediaTurma=0;
            System.out.println("Não é possível efetuar a média sem notas!");
        }

        return mediaTurma;
    }