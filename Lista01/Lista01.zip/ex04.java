    // Função privada para o Fator de Integridade/Segurança
    // Função que retorna double, pois o desconto é com casa decimal, fator de Robustez
    // Função Modularizada aumentando a qualidade
    private static double calcDesconto() {
        double desconto;

        // Fato de Eficiência pois diminui a quantidade de comparações
        // Fator de Legibilidade e Inteligibilidade aprimorados
        // O desconto maior é para idosos ou estudantes, então condição principal é essa. Fator de Correção
        if(idade>=65 || estudante==true)
            desconto = 0.5;
        else if(assinante==true)
            desconto = 0.2;
        else
            desconto = 0;

        return desconto;
    }